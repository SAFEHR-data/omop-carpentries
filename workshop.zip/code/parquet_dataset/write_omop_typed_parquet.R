#' Coerce OMOP string date columns to Date (columns named with suffix `_date`).
coerce_omop_date_column <- function(x) {
  if (inherits(x, "Date")) {
    return(x)
  }
  if (inherits(x, "POSIXct")) {
    return(as.Date(x))
  }
  x <- as.character(x)
  x[x %in% c("NA", "NULL", "")] <- NA_character_
  d <- as.Date(rep(NA, length(x)))
  ok <- !is.na(x)
  if (!any(ok)) {
    return(d)
  }
  d[ok] <- as.Date(x[ok], format = "%Y-%m-%d")
  still <- ok & is.na(d)
  if (any(still)) {
    d[still] <- as.Date(x[still], format = "%d/%m/%Y")
  }
  d
}

#' Coerce OMOP string datetime columns to POSIXct in UTC (suffix `_datetime`).
coerce_omop_datetime_column <- function(x) {
  if (inherits(x, "POSIXct")) {
    return(as.POSIXct(format(x, tz = "UTC"), tz = "UTC"))
  }
  if (inherits(x, "Date")) {
    return(as.POSIXct(x, tz = "UTC"))
  }
  x <- as.character(x)
  x[x %in% c("NA", "NULL", "")] <- NA_character_
  out <- as.POSIXct(rep(NA, length(x)), tz = "UTC")
  ok <- !is.na(x)
  if (!any(ok)) {
    return(out)
  }
  formats <- c(
    "%Y-%m-%d %H:%M:%OS",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%d/%m/%Y %H:%M:%OS",
    "%d/%m/%Y %H:%M:%S",
    "%d/%m/%Y %H:%M"
  )
  for (fmt in formats) {
    still <- ok & is.na(out)
    if (!any(still)) {
      break
    }
    out[still] <- as.POSIXct(x[still], tz = "UTC", format = fmt)
  }
  out
}

#' Apply date/datetime coercion to columns following OMOP naming conventions.
coerce_omop_date_columns <- function(df) {
  nm <- names(df)
  dt_cols <- nm[endsWith(nm, "_datetime")]
  date_cols <- nm[endsWith(nm, "_date")]
  dplyr::mutate(
    df,
    dplyr::across(dplyr::any_of(dt_cols), coerce_omop_datetime_column),
    dplyr::across(dplyr::any_of(date_cols), coerce_omop_date_column)
  )
}

#' Collect each OMOP table, coerce `*_date` / `*_datetime` columns, write parquet.
#'
#' Output layout mirrors the input: `out_dir/<table>/<table>.parquet`.
#'
#' @param omop Named list of [arrow::Dataset] objects from [open_omop_dataset()].
#' @param out_dir Root directory to create (e.g. `file.path(dirname(src), "new")`).
#' @return `out_dir`, invisibly.
write_omop_typed_parquet <- function(omop, out_dir) {
  stopifnot(is.list(omop), length(out_dir) == 1L, nzchar(out_dir))
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  for (tbl in names(omop)) {
    df <- omop[[tbl]] |>
      dplyr::collect() |>
      coerce_omop_date_columns()
    tbl_dir <- file.path(out_dir, tbl)
    dir.create(tbl_dir, recursive = TRUE, showWarnings = FALSE)
    arrow::write_dataset(df, file.path(tbl_dir))
  }
  invisible(out_dir)
}

write_omop_typed_parquet(omop, "test")

