connect_cdm <- function() {
  # Connect to the GiBleed database if not already connected
  if (!exists("cdm") || !inherits(cdm, "cdm_reference")) {
    db_name <- "GiBleed"
    CDMConnector::requireEunomia(datasetName = db_name)
    con <- DBI::dbConnect(duckdb::duckdb(),
                          dbdir = CDMConnector::eunomiaDir(datasetName = db_name))
    cdm <- CDMConnector::cdmFromCon(con, cdmSchema = "main", writeSchema = "main")
  }
}
